
import Mmenu from 'mmenu-js';
document.addEventListener('DOMContentLoaded', () => {
    new Mmenu(document.querySelector("#menu"), {
        offCanvas: {
           position: "right-front"
        }
     });
  });

  import WOW from "wow.js";
  document.addEventListener('DOMContentLoaded', function() {
    const wow = new WOW();
    wow.init();
});